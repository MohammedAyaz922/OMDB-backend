﻿const db = require('_helpers/db');

module.exports = {
    getAll,
    getById,
    create,
    update,
    delete: _delete
};

async function getAll() {
    return await db.Movie.findAll();
}

async function getById(id) {
    return await getMovie(id);
}

async function create(params) {
    // validate
    if (await db.Movie.findOne({ where: { title: params.title } })) {
        throw 'title "' + params.title + '" is already registered';
    }

    const Movie = new db.Movie(params);

    // save Movie
    await Movie.save();
}

async function update(id, params) {
    const Movie = await getMovie(id);

    // validate
    const titleChanged = params.title && Movie.title !== params.title;
    if (titleChanged && await db.Movie.findOne({ where: { title: params.title } })) {
        throw 'title "' + params.title + '" is already registered';
    }

    // copy params to Movie and save
    Object.assign(Movie, params);
    await Movie.save();
}

async function _delete(id) {
    const Movie = await getMovie(id);
    await Movie.destroy();
}

// helper functions

async function getMovie(id) {
    const Movie = await db.Movie.findByPk(id);
    if (!Movie) throw 'Movie not found';
    return Movie;
}
